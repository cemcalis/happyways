import sqlite3 from "sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.join(__dirname, "happyways.db");
let db;

export async function initDB() {
  return new Promise((resolve, reject) => {
    db = new sqlite3.Database(dbPath, (err) => {
      if (err) {
        console.error("[DB] connection error:", err.message);
        reject(err);
      } else {
        console.log("[DB] connected:", dbPath);

        db.serialize(() => {
          // Users table (ensure columns exist even on older DBs)
          db.run(`
            CREATE TABLE IF NOT EXISTS users (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              full_name TEXT,
              first_name TEXT,
              last_name TEXT,
              phone TEXT,
              email TEXT UNIQUE NOT NULL,
              password TEXT NOT NULL,
              created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
          `);

          db.run(`
            CREATE TABLE IF NOT EXISTS cars (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              model TEXT NOT NULL,
              year INTEGER,
              image TEXT,
              price REAL NOT NULL
            )
          `);

          db.run(`
            CREATE TABLE IF NOT EXISTS locations (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL
            )
          `);

          db.run(`
            CREATE TABLE IF NOT EXISTS campaigns (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              title TEXT NOT NULL,
              description TEXT,
              start_date TEXT,
              end_date TEXT,
              image TEXT,
              price_text TEXT,
              note TEXT
            )
          `);

          db.run(`
            CREATE TABLE IF NOT EXISTS reservations (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              user_id INTEGER NOT NULL,
              car_id INTEGER NOT NULL,

              user_name TEXT,
              user_email TEXT,
              user_phone TEXT,
              car_model TEXT,
              car_year INTEGER,
              car_image TEXT,

              pickup_location TEXT NOT NULL,
              dropoff_location TEXT NOT NULL,
              pickup_location_id INTEGER,
              dropoff_location_id INTEGER,
              pickup_date TEXT NOT NULL,
              dropoff_date TEXT NOT NULL,
              pickup_time TEXT NOT NULL,
              dropoff_time TEXT NOT NULL,
              pickup_datetime TEXT,
              dropoff_datetime TEXT,

              total_price REAL NOT NULL,
              status TEXT NOT NULL DEFAULT 'confirmed',
              payment_status TEXT DEFAULT 'paid',
              payment_id TEXT,
              notes TEXT,

              created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
              updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

              FOREIGN KEY (user_id) REFERENCES users(id),
              FOREIGN KEY (car_id) REFERENCES cars(id),
              FOREIGN KEY (pickup_location_id) REFERENCES locations(id),
              FOREIGN KEY (dropoff_location_id) REFERENCES locations(id)
            )
          `);

          // Refresh tokens
          db.run(`
            CREATE TABLE IF NOT EXISTS refresh_tokens (
              user_id INTEGER NOT NULL,
              token TEXT PRIMARY KEY,
              expires_at INTEGER NOT NULL,
              created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY (user_id) REFERENCES users(id)
            )
          `);

          // Backfill missing columns in users if DB existed with older schema
          db.all("PRAGMA table_info(users)", (e, rows) => {
            if (e) {
              console.error("[DB] table_info users error:", e.message);
            } else {
              const names = new Set((rows || []).map(r => r.name));
              const pending = [];
              if (!names.has("first_name")) pending.push("ALTER TABLE users ADD COLUMN first_name TEXT");
              if (!names.has("last_name")) pending.push("ALTER TABLE users ADD COLUMN last_name TEXT");
              if (!names.has("phone")) pending.push("ALTER TABLE users ADD COLUMN phone TEXT");
              let chain = Promise.resolve();
              pending.forEach(sql => {
                chain = chain.then(() => new Promise(r => db.run(sql, () => r())));
              });
            }
          });

          resolve();
        });
      }
    });
  });
}

export function getDB() {
  if (!db) throw new Error("[DB] not initialized");
  return db;
}

// Promise-based helpers for sqlite3 callback API
export function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => {
    try {
      const database = getDB();
      database.all(sql, params, (err, rows) => {
        if (err) return reject(err);
        resolve(rows || []);
      });
    } catch (e) {
      reject(e);
    }
  });
}

export function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => {
    try {
      const database = getDB();
      database.get(sql, params, (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    } catch (e) {
      reject(e);
    }
  });
}

export async function closeDB() {
  return new Promise((resolve, reject) => {
    if (!db) return resolve();
    db.close((err) => {
      if (err) {
        console.error("[DB] close error:", err.message);
        reject(err);
      } else {
        console.log("[DB] closed.");
        resolve();
      }
    });
  });
}


export function getUserByEmail(email) {
  return new Promise((resolve, reject) => {
    if (!db) return reject(new Error("[DB] not initialized"));
    const normalized = String(email || "").trim().toLowerCase();
    db.get(`SELECT * FROM users WHERE LOWER(email) = ?`, [normalized], (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}
